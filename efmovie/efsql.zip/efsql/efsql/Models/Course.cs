﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace efsql.Models
{
    public class Course
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]//指定主键而不是让数据库生成它
        public int CourseID { get; set; }
        public string Title { get; set; }
        public int Credits { get; set; }
        public ICollection<Enrollment> Enrollment { get; set; }
    }
}